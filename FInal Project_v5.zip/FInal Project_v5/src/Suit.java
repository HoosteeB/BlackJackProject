
public enum Suit {
	spades,
	diamonds,
	clubs,
	hearts
}
