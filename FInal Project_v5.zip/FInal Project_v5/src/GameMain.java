public class GameMain {
	public static void main(String[] args) {
		int initialAmount = 1000;
		GameManager game = new GameManager(initialAmount);		
	}
}