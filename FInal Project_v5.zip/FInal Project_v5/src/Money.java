
public class Money {
	
}
